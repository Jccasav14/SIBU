<template>
  <header class="nav">
    <div class="inner">
      <div class="leftGroup">
        <!-- Brand -->
        <div class="brand" @click="goHome">
          <div class="logoBadge">S</div>
          <div class="brandText">
            <div class="title">SIBU</div>
            <div class="sub">Bienestar Universitario</div>
          </div>
        </div>

        <!-- Main nav (módulos) -->
        <nav v-if="isAuthed" class="mainNav" aria-label="Main">
          <!-- Admin / Professional modules -->
          <template v-if="!isInsurance">
            <RouterLink class="navLink" to="/cases">Casos</RouterLink>
            <RouterLink class="navLink" to="/agenda">Citas</RouterLink>
            <RouterLink class="navLink" to="/reports">Reportes</RouterLink>
            <RouterLink v-if="isAdmin" class="navLink" to="/admin">Admin</RouterLink>
            <RouterLink v-if="isAdmin" class="navLink" to="/insurance/overview">Seguros</RouterLink>
          </template>

          <!-- Insurance module -->
          <template v-else>
            <RouterLink class="navLink" to="/insurance/overview">Seguros</RouterLink>
</template>
        </nav>
      </div>

      <!-- Right: dropdown usuario -->
      <div class="right">
        <template v-if="!isAuthed">
          <RouterLink class="link ghost" to="/login">Iniciar sesión</RouterLink>
          <RouterLink class="btn" to="/register">Crear cuenta</RouterLink>
        </template>

        <template v-else>
          <button class="userBtn" @click="toggleMenu" ref="btnRef">
            <span class="avatar">{{ initials }}</span>
            <span class="who">
              <span class="name">{{ displayName }}</span>
            </span>
            <span class="chev">▾</span>
          </button>

          <div v-if="open" class="menu" ref="menuRef">
            <button class="item" @click="goProfile">Perfil</button>
            <button class="item" @click="goChangePassword">Cambiar contraseña</button>

            <div class="sep"></div>

            <button class="item danger" @click="logout">Cerrar sesión</button>
          </div>
        </template>
      </div>
    </div>
  </header>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from "vue";
import { useRouter } from "vue-router";
import { auth } from "../stores/auth";

const router = useRouter();

const isAuthed = computed(() => auth.isAuthenticated());
const user = computed(() => auth.user() || null);

const role = computed(() => String(user.value?.role || "").toLowerCase());
const isAdmin = computed(() => role.value === "admin");
const isPro = computed(() => role.value === "professional");
const isInsurance = computed(() => role.value === "insurance");

const displayName = computed(() => user.value?.email || "Usuario");

const initials = computed(() => {
  const s = (user.value?.email || "U").trim();
  return s[0]?.toUpperCase() || "U";
});

// dropdown logic
const open = ref(false);
const btnRef = ref(null);
const menuRef = ref(null);

function toggleMenu() {
  open.value = !open.value;
}

function closeMenu() {
  open.value = false;
}

function onDocClick(e) {
  if (!open.value) return;
  const btn = btnRef.value;
  const menu = menuRef.value;
  const t = e.target;
  if (btn && btn.contains(t)) return;
  if (menu && menu.contains(t)) return;
  closeMenu();
}

onMounted(() => document.addEventListener("mousedown", onDocClick));
onBeforeUnmount(() => document.removeEventListener("mousedown", onDocClick));

function goHome() {
  if (!isAuthed.value) router.push("/login");
  else if (isAdmin.value) router.push("/admin");
  else if (isPro.value) router.push("/dashboard");
  else if (isInsurance.value) router.push("/insurance");
  else router.push("/me");
}

function goProfile() {
  closeMenu();
  if (isAdmin.value) router.push("/perfil");
  else if (isPro.value) router.push("/perfil-pro");
  else if (isInsurance.value) router.push("/perfil-insurance");
  else router.push("/me");
}

function goChangePassword() {
  closeMenu();
  router.push("/change-password");
}

function logout() {
  closeMenu();
  auth.logout();
  router.push("/login");
}
</script>

<style scoped>
/* Navbar: limpio y elegante */
.nav {
  position: sticky;
  top: 0;
  z-index: 50;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid #e5e7eb;
}

.inner {
  max-width: 1100px;
  margin: 0 auto;
  padding: 12px 18px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
}

.leftGroup {
  display: flex;
  align-items: center;
  gap: 18px;
  min-width: 0;
}

.leftGroup{
  display:flex;
  align-items:center;
  gap:16px;
  min-width: 0;
}

/* Brand */
.brand {
  display: flex;
  align-items: center;
  gap: 12px;
  cursor: pointer;
  user-select: none;
}

.mainNav{
  display:flex;
  align-items:center;
  gap: 8px;
}

.navLink{
  text-decoration:none;
  padding: 8px 12px;
  border-radius: 12px;
  font-weight: 800;
  color: #111827;
}

.navLink:hover{ background:#f3f4f6; }

.navLink.router-link-active{
  background:#eff6ff;
  color:#2563eb;
  border: 1px solid #bfdbfe;
}

.logoBadge {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: #2563eb;
  color: #fff;
  font-weight: 800;
  font-size: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  letter-spacing: -0.5px;
  box-shadow: 0 4px 10px rgba(37, 99, 235, 0.25);
}

.brandText .title {
  font-weight: 800;
  line-height: 1.05;
  color: #111827;
}
.brandText .sub {
  font-size: 0.78rem;
  color: #6b7280;
}

/* Right area */
.right {
  display: flex;
  align-items: center;
  gap: 10px;
}

/* Main nav */
.mainNav {
  display: flex;
  align-items: center;
  gap: 10px;
}

.navLink {
  text-decoration: none;
  color: #111827;
  padding: 8px 12px;
  border-radius: 12px;
  font-weight: 800;
  font-size: 0.92rem;
}

.navLink:hover {
  background: #f3f4f6;
}

.navLink.router-link-active {
  background: #eff6ff;
  color: #2563eb;
  border: 1px solid #bfdbfe;
}

.link {
  text-decoration: none;
  color: #111827;
  padding: 8px 12px;
  border-radius: 12px;
  font-weight: 600;
  font-size: 0.92rem;
}

.link:hover {
  background: #f3f4f6;
}

.link.ghost {
  color: #374151;
}

.btn {
  text-decoration: none;
  padding: 8px 14px;
  border-radius: 12px;
  border: 1px solid #d1d5db;
  background: #111827;
  color: #fff;
  font-weight: 700;
  font-size: 0.92rem;
}

.btn:hover {
  background: #0b1220;
}

/* User button */
.userBtn {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 10px;
  border-radius: 14px;
  border: 1px solid #e5e7eb;
  background: #fff;
  cursor: pointer;
}

.userBtn:hover {
  background: #f9fafb;
}

.avatar {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  background: #f3f4f6;
  color: #2563eb;          /* ✅ inicial azul */
  border: 1px solid #dbeafe;
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
}

.who {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  line-height: 1.1;
}

.name {
  font-weight: 700;
  font-size: 0.9rem;
  color: #111827;
}

.chev {
  color: #6b7280;
  font-size: 0.85rem;
  margin-left: 2px;
}

/* Menu */
.menu {
  position: absolute;
  margin-top: 8px;
  right: 18px;
  top: 64px;
  width: 220px;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 14px;
  box-shadow: 0 12px 28px rgba(0,0,0,0.10);
  padding: 6px;
}

.item {
  width: 100%;
  text-align: left;
  padding: 10px 10px;
  border: none;
  background: transparent;
  border-radius: 10px;
  cursor: pointer;
  font-weight: 600;
  color: #111827;
}

.item:hover {
  background: #f3f4f6;
}

.item.danger {
  color: #b91c1c;
}

.sep {
  height: 1px;
  background: #e5e7eb;
  margin: 6px 4px;
}

.mainNav{
  display:flex;
  align-items:center;
  gap:10px;
  margin-left:18px;
}
.navLink{
  text-decoration:none;
  color:#374151;
  font-weight:600;
  padding:8px 10px;
  border-radius:10px;
}
.navLink:hover{
  background:#f3f4f6;
}
.navLink.router-link-active{
  background:#eff6ff;
  color:#2563eb;
}
</style>